#include "screens/screen.h"

Screen::Screen() {}
Screen::~Screen() {}