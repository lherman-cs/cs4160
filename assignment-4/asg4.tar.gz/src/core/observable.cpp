#include "core/observable.h"

Observable::Observable() : subscribers() {}

Observable::~Observable() {}