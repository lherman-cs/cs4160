#include "core/event.h"

Event::~Event() {}