#!/bin/bash

/emsdk_portable/sdk/embuilder.py build sdl2 sdl2-image sdl2-image-png sdl2-ttf zlib libpng