#pragma once

#include "shapes/container.h"

std::shared_ptr<const Container> buildGopher(int x, int y, int h);